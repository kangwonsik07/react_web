// 지역검색 실패
function NotFound() {
   return <h1>잘못된 경로입니다.</h1>
}

export default NotFound
