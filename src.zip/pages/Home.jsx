// 메인화면

import Banner from '../components/Banner'
import Footer from '../components/Footer'

import '../style/home.css'

function Home() {
   return (
      <div>
         <div>
            <Banner />
         </div>

         <Footer />
      </div>
   )
}

export default Home
