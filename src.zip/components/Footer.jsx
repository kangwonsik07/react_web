import './css/Footer.css'

function Footer() {
   return (
      <footer>
         <p>Weather</p>
      </footer>
   )
}

export default Footer
